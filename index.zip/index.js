const express = require("express");
const app = express();

const bodyparser = require("body-parser");

//import routes
const authRouter = require("./routes/auth");
const mongoose = require("mongoose");
const postsrouter = require("./routes/posts");
const dotenv = require("dotenv").config();
//connect database
mongoose.connect(
  "mongodb+srv://authentication:9KDWMpS1tZzscGpx@cluster0.dziql.mongodb.net/firstApi?retryWrites=true&w=majority",
  {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  },
  () => console.log("connected")
);
//
app.use(bodyparser.urlencoded({ extended: false }));
app.use(bodyparser.json());
// app.use(express, json());
//roue middleware
app.use("/api/user", authRouter);
app.use("/api/posts", postsrouter);
app.listen(3000, () => console.log("server start"));
