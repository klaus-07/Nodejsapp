const router = require("express").Router();
const User = require("../models/user");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const dotenv = require("dotenv");
const { response } = require("express");
const { findById, count } = require("../models/user");
const { post } = require("./posts");
router.get("/register", (req, res) => {
  User.find()
    .select("name email password")
    .exec()
    .then((doc) => {
      const response = {
        user: doc.map((doc) => {
          return {
            name: doc.name,
            email: doc.email,
            password: doc.password,
            id: doc._id,
          };
        }),
      };
      res.status(200).json(response);
    })
    .catch((err) => {
      console.log(err);
      res.status(500).json({ error: err });
    });
});
router.post("/register", async (req, res) => {
  const emailexit = await User.findOne({ email: req.body.email });
  if (emailexit) return res.status(500).send("email does exists BBBBeta");
  //hash password
  const salt = await bcrypt.genSalt(10);
  const hash = await bcrypt.hash(req.body.password, salt);

  //create a new user
  const user = new User({
    name: req.body.name,
    email: req.body.email,
    password: hash,
  });
  try {
    const saveduser = await user.save();
    res.status(201).json(saveduser);
  } catch (err) {
    res.status(400).send(err);
  }
});
router.post("/login", async (req, res) => {
  // checking if email does't exists
  const user = await User.findOne({ email: req.body.email });
  if (!user) return res.status(500).send("email is wrong");
  // password is correct
  const validpass = await bcrypt.compare(req.body.password, user.password);
  if (!validpass) {
    return res.status(500).json("invalid password");
  }
  const token = jwt.sign({ _id: user._id }, process.env.TOKEN_SECRET);
  res.header("auth-token", token).send(token);
  // res.send("successfully logd in");
});
router.post("/:id", async (req, res, next) => {
  try {
    const id = req.params.id;
    const update = req.body;
    const options = { new: true };
    const result = await User.findByIdAndUpdate(id, update, options);
    res.send(result);
  } catch (error) {
    res.status(500).json(error);
  }
});

module.exports = router;
